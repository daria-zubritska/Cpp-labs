#include <iostream>;
#include "05LAB.h";
using namespace std;

int main() {
	
	AComplex a = AComplex(1, 1);
	AComplex b = AComplex(2, 1);

	AComplex c = AComplex();
	
	c = a + b;
	cout << "a + b = " << c << endl;

	c = b + 3;
	cout << "b + 3 = " << c << endl;

	c += b;
	cout << "c += b = " << c << endl;

	c += 3;
	cout << "c += 3 = " << c << endl;

	TComplex d = TComplex(1, 1);
	TComplex e = TComplex(2, 1);

	TComplex f = TComplex();

	f = d * e;
	cout << "d * e = " << f << endl;

	f = d * 3;
	cout << "d * 3 = " << f << endl;

	f *= d;
	cout << "f *= d = " << f << endl;

	f *= 3;
	cout << "f *= 3 = " << f << endl;

	
	return 0;
}