#include <iostream>;
#include "05LAB.h";
using namespace std;

int AComplex::_AfreeID = 0;

AComplex::AComplex(double re, double im) : _re(re), _im(im), _ID(++_AfreeID)
{
    cout << "Creating: " << _re << " + " << _im << "i; " << "ID of AComplex: " << _ID << endl;
}

AComplex::AComplex(double re) : AComplex(re, 0)
{
    
}

AComplex::AComplex() : AComplex(0, 0)
{

}

AComplex::~AComplex()
{
    cout << "Deleting: " << _re << " + " << _im << "i; " << "ID of AComplex: " << _ID << endl;
}
const double& AComplex::re() const
{
    return _re;
}
const double& AComplex::im() const
{
    return _im;
}

const double& AComplex::ID() const
{
    return _ID;
}

double& AComplex::re()
{
    return _re;
}

double& AComplex::im()
{
    return _im;
}

AComplex& AComplex::operator=(const AComplex& a)
{
    this->re() = a.re();
    this->im() = a.im();
    return *this;
}


const AComplex operator+(const AComplex& a, const AComplex& b)
{
    return AComplex(a.re() + b.re(), a.im() + b.im());
}

const AComplex operator+(const AComplex& a, const double& b)
{
    return AComplex(a.re() + b, a.im());
}

const AComplex operator+=(AComplex& a, const AComplex& b)
{
    return a = AComplex(a.re() + b.re(), a.im() + b.im());
}

const AComplex operator+=(AComplex& a, const double& b)
{
    return a = AComplex(a.re() + b, a.im());
}






int TComplex::_TfreeID = 0;

TComplex::TComplex(double r = 1, double phi = 0) : _r(r), _phi(phi), _ID(++_TfreeID)
{
    cout << "Creating: " << _r << "(cos(" << _phi << ") + i sin(" << _phi << ")); " << "ID of TComplex: " << _ID << endl;
}

TComplex::TComplex(double r) : TComplex(r, 0)
{

}

TComplex::TComplex() : TComplex(0, 0)
{

}

TComplex::~TComplex()
{
    cout << "Deleting: " << _r << "(cos(" << _phi << ") + i sin(" << _phi << ")); " << "ID of TComplex: " << _ID << endl;
}

const double& TComplex::r() const
{
    return _r;
}

TComplex& TComplex::operator=(const TComplex& a)
{
    this->r() = a.r();
    this->phi() = a.phi();
    return *this;
}

const double& TComplex::phi() const
{
    return _phi;
}

const double& TComplex::ID() const
{
    return _ID;
}

double& TComplex::r()
{
    return _r;
}

double& TComplex::phi()
{
    return _phi;
}

const TComplex operator*(const TComplex& a, const TComplex& b)
{
    return TComplex(a.r() * b.r(), a.phi() + b.phi());
}

const TComplex operator*(const TComplex& a, const double& b)
{
    return TComplex(a.r() * b, a.phi());
}

const TComplex operator*=(TComplex& a, const TComplex& b)
{
    return a = TComplex(a.r() * b.r(), a.phi() + b.phi());
}

const TComplex operator*=(TComplex& a, const double& b)
{
    return a = TComplex(a.r() * b, a.phi());
}


ostream& operator<<(ostream& os, const AComplex& a)
{
    os << a.re() << " + " << a.im() << "i; " << "ID of AComplex: " << a.ID() << endl;
    return os;
}

ostream& operator<<(ostream& os, const TComplex& t)
{
    os << t.r() << "(cos(" << t.phi() << ") + i sin(" << t.phi() << ")); "<< "ID of TComplex: " << t.ID() << endl;
    return os;
}
