#ifndef _COMPLEX_H_
#define _COMPLEX_H_

#include <iostream>
using namespace std;

class AComplex
{
private:
	int _ID;
	static int _AfreeID;
	double _re, _im;
public:
	AComplex(double re, double im);
	AComplex(double re);
	AComplex();

	~AComplex();

	const double& re() const;
	const double& im() const;
	const double& ID() const;

	double& re();
	double& im();

	AComplex& operator=(const AComplex&);
};

const AComplex operator+(const AComplex&, const AComplex&);
const AComplex operator+(const AComplex&, const double&);

const AComplex operator+=(AComplex&, const AComplex&);
const AComplex operator+=(AComplex&, const double&);

ostream& operator<<(ostream& os, const AComplex& a);


class TComplex
{
private:
	int _ID;
	static int _TfreeID;
	double _r, _phi;
public:
	TComplex(double r, double phi);
	TComplex(double r);
	TComplex();

	~TComplex();

	const double& r() const;
	const double& phi() const;
	const double& ID() const;

	double& r();
	double& phi();

	TComplex& operator=(const TComplex&);
};

const TComplex operator*(const TComplex&, const TComplex&);
const TComplex operator*(const TComplex&, const double&);

const TComplex operator*=(TComplex&, const TComplex&);
const TComplex operator*=(TComplex&, const double&);

ostream& operator<<(ostream& os, const TComplex& t);


#endif