#include <iostream>;
#include <string>;
#include "String.h";
#pragma warning(disable : 4996);

using namespace std;


int main() 
{
	const char* p1 = "string"; 
	String s1(p1); 
	const char p2 = 'A';
	String s2(p2);

	cout << s1[0] << endl;
	cout << s1 << endl;
	cout << s1 + s2 << endl;
	s1 = s2;
	cout << s1 << endl;

	String s3(p1);

	s1 = s3;
	cout << s1 << endl;

	if (s1 == s3) {
		cout << "s1 = s3" << endl;
	}
	else {
		cout << "s1 != s3" << endl;
	}

	if (s2 != s3) {
		cout << "s2 != s3" << endl;
	}
	else {
		cout << "s2 = s3" << endl;
	}

	string p3("string from string");
	String s4(p3);

	cout << s4 << endl;
	
	p1 = nullptr;

	return 0;
}