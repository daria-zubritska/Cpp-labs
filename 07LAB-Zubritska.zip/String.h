﻿#pragma once

#include <string>;
#include <iostream>;

using namespace std;

class String {
private:
	size_t _len;
	char* _allocator;
public:
	class BadString;
	String();
	String(const char);
	String(const char*);
	String(const string);
	String(String&);
	~String();

	char& operator[](size_t) const;

	String& operator= (String&);

	bool operator== (const String&);

	String operator+ (const String&);

	bool operator!= (const String&);

	const size_t len() const { return _len; }
};

ostream& operator<< (ostream& so, const String& s);

class String::BadString {
private:
	const string _reason; // Причина аварійної ситуації
	const size_t _index; // Символ, на обробці якого вона виникла
public:
	BadString(string reason = "", const size_t index = 0) :
		_reason(reason), _index(index) {
		return;
	}
	~BadString() {}
	// Діагностичне повідомлення 
	void diagnose() const {
		cerr << _reason << endl;
		if (_index != 0)
			cerr << ' ' << _index << endl;
	}
};