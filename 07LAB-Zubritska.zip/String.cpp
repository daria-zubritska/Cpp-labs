﻿#include "String.h"
#pragma warning(disable : 4996);

String::String() :_allocator(new char[1]), _len(0) {
	_allocator[0] = '\0';
	return;
}

String::String(const char c) : _allocator(new char[2]), _len(1) {
	_allocator[0] = c; _allocator[1] = '\0';
	return;
}

String::String(const char* ps)
{
	if (ps == 0)
		throw BadString("Attempt to use not defined pointer"); 
		_len = strlen(ps); _allocator = new char[_len + 1];
	strcpy(_allocator, ps);
	return;
}

String::String(const string s) : _len(s.length()), _allocator(new char[_len + 1])
{
	strcpy(_allocator, s.c_str());
}

String::String(String& s) :_len(s._len), _allocator(new char[_len + 1]) 
{
	strcpy(_allocator, s._allocator);
	return;
}

String::~String()
{
	_allocator = nullptr;
}

char& String::operator[](size_t j) const
{
	if (j >= _len) throw 1;
	return _allocator[j];
}

String& String::operator=(String& s)
{
	if (this == &s) return *this;

	_allocator = nullptr;
	_len = s.len();

	_allocator = new char[_len];

	strcpy(_allocator, s._allocator);
	return *this;
}

bool String::operator==(const String& s)
{
	if (this->len() != s.len()) return false;

	size_t cap = this->len();
	size_t n = 0;
	while ((n < cap) && (_allocator[n] == s[n])) {
		n++;
	}
	return (n == cap);
}

String String::operator+(const String& s)
{
	size_t len = this->len() + s.len();

	char* newstr = new char[len];

	strcpy(newstr, _allocator);
	strcat(newstr, s._allocator);
	
	_allocator = nullptr;
	_len = len;
	_allocator = newstr;
	
	return *this;
}

bool String::operator!=(const String& s)
{
	return !(*this == s);
}

ostream& operator<<(ostream& os, const String& s)
{
	if (s.len() > 0)
	{
		for (int i = 0; i < s.len(); i++)
			os << s[i];
	}
	else os << "";

	return os;
}
