﻿#pragma once
#include <iostream>;
#include "Point.h";
#include "Segment.h";
#include "HTetragon.h";
#include "HRectangle.h";

using namespace std;

class HSquare : public HTetragon
{
public:
	//уся реалізація знаходиться у HTetragon
	HSquare(const Point& a, const double h) : HTetragon(a, h, h, 90)
	{};
	HSquare(const double ax = 0, const double ay = 0, const double h = 1) : HTetragon(ax, ay, h, h, 90)
	{};

	//конструктор найменшого квадрату у який можна вкласти даний прямокутник
	HSquare(HRectangle& r) : HSquare(r.apexA().x(), r.apexA().y(), ((r.h() > r.w()) ? r.h() : r.w())) {};

	~HSquare() {};

};


