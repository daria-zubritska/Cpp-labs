﻿#pragma once
#include <iostream>;
#include "Point.h";
#include "Segment.h";
#include "HTetragon.h";

using namespace std;

class HRectangle : public HTetragon
{
public:
	//уся реалізація знаходиться у HTetragon
	HRectangle(const Point& a, const double h, const double w) : HTetragon(a, h, w, 90)
	{};
	HRectangle(const double ax = 0, const double ay = 0, const double h = 1, const double w = 2) : HTetragon(ax, ay, h, w, 90)
	{};

	~HRectangle() 
	{};

};


