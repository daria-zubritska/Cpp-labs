﻿#include <iostream>;
#include "Point.h";
#include "HRectangle.h";
#include "HSquare.h";
#include "HDiamond and HParallelogram.h";
#include "Container.h";

using namespace std;

int main()
{
	//Знак мінус прибирається у конструкторі, отже всі координати додатні
	Point a(1, 1);
	HSquare s1(a, 5), s2(4, 3, 1), s3(3, 2, -3), s4(0, 0, 4);
	HRectangle r1(a, 5, -6), r2(2, 1, 1, 2), r3(1, 2, 2, 1), r4(0, 0, 3, 4);

	Container<HSquare> cS;
	Container<HRectangle> cR;

	try {
		try {
			cS.add(s1);
			cS.add(s2);
			cS.add(s3);
			cS.add(s4);

			cR.add(r1);
			cR.add(r2);
			cR.add(r3);
			cR.add(r4);

			cout << "GETTERS" << endl;
			cout << "s1: " << endl;
			cout << cS[0] << endl;
			cout << "getters:" << endl;
			cout << cS[0].apexA() << endl;
			cout << cS[0].apexB() << endl;
			cout << cS[0].apexC() << endl;
			cout << cS[0].apexD() << endl;

			cout << "r1: " << endl;
			cout << cR[0] << endl;
			cout << "getters:" << endl;
			cout << cR[0].apexA() << endl;
			cout << cR[0].apexB() << endl;
			cout << cR[0].apexC() << endl;
			cout << cR[0].apexD() << endl;

			//знак мінус прибирається у сеттері
			cout << "\n SETTERS" << endl;
			cout << "s2:" << endl;
			cout << cS[1] << endl;
			cout << "cS[1].setA(2, 2);" << endl;
			cS[1].setA(2, 2);
			cout << cS[1] << endl;

			cout << "cS[1].setA(-1, -1);" << endl;
			cS[1].setA(-1, -1);
			cout << cS[1] << endl;

			cout << "r2:" << endl;
			cout << cR[1] << endl;
			cout << "cR[1].setA(2, 2);" << endl;
			cR[1].setA(2, 2);
			cout << cR[1] << endl;

			cout << "cR[1].setA(-1, -1);" << endl;
			cR[1].setA(-1, -1);
			cout << cR[1] << endl;

			cout << "\n SIDES AND AREA" << endl;
			cout << "s3:" << endl;
			cout << "area: " << cS[2].area() << endl;
			cout << "side a: " << cS[2].side_a() << endl;
			cout << "side b: " << cS[2].side_b() << endl;
			cout << "side c: " << cS[2].side_c() << endl;
			cout << "side d: " << cS[2].side_d() << endl;

			cout << "r3:" << endl;
			cout << "area: " << cR[2].area() << endl;
			cout << "side a: " << cR[2].side_a() << endl;
			cout << "side b: " << cR[2].side_b() << endl;
			cout << "side c: " << cR[2].side_c() << endl;
			cout << "side d: " << cR[2].side_d() << endl;

			cout << "\n OPERATOR <" << endl;
			cout << "s2 < s1" << endl;
			cout << (cS[1] < cS[0]) << endl;

			cout << "r1 < r2" << endl;
			cout << (cR[0] < cR[1]) << endl;

			cout << "\n OPERATOR +" << endl;
			cout << "s1 + s3" << endl;
			HTetragon temp = (cS[0] + cS[2]);
			cout << temp << endl;

			cout << "r1 + r3" << endl;
			temp = (cR[0] + cR[2]);
			cout << temp << endl;

			cout << "\n HSquare(HRectangle&)" << endl;
			HSquare Sr(r1);
			cout << Sr << endl;

			cout << "\n FIND ALL SMALLER THAN GIVEN s4/r4" << endl;
			Container<HSquare> allSmallS;
			cS.allSmallerThan(cS[3], allSmallS);

			for (size_t i = 0; i < allSmallS.size(); ++i) {
				cout << allSmallS[i] << endl;
			}

			Container<HRectangle> allSmallR;
			cR.allSmallerThan(cR[3], allSmallR);

			for (size_t i = 0; i < allSmallR.size(); ++i) {
				cout << allSmallR[i] << endl;
			}

			cout << "\n BUILD SQUARE UNITING ALL SQUARES FROM CONTAINER" << endl;
			HTetragon res;
			for (size_t i = 0; i < cS.size(); ++i) {
				res = res + cS[i];
			}

			cout << res << endl;

			cout << "\n HDiamond AND HParallelogram CONSTRUCTORS" << endl;
			HDiamond d1(a, 3, 60), d2(1, 2, 3, 60), d3;
			HParallelogram p1(a, 3, 2, 60), p2(1, 2, 3, 4, 60), p3;

			cout << "diamonds" << endl;
			cout << d1 << endl;
			cout << d2 << endl;
			cout << d3 << endl;

			cout << "parallelograms" << endl;
			cout << p1 << endl;
			cout << p2 << endl;
			cout << p3 << endl;
		}
		catch (Container<HRectangle>::BadCon& e) {
			e.diagnose();
		}
	} catch (Container<HSquare>::BadCon& e){
		e.diagnose();
	}
	return 0;
}