﻿#pragma once
#include <iostream>;
#include "Point.h";
#include "Segment.h";

using namespace std;

//2
class HTetragon
{
private:

	Point _a, _b, _c, _d;
	Segment* _ab, * _bc, * _cd, * _da;

	double _h, _w;
	size_t _angle;

	double _myPi = 3.14159;

public:

	HTetragon(const Point& a, const double h, const double w, const size_t angle) : _a(a), _angle((angle < 180) ? angle : (angle - 180)), _ab(nullptr), _bc(nullptr), _cd(nullptr), _da(nullptr)
	{
		//на довжини накладається "модуль"
		_h = (h >= 0) ? h: -h;
		_w = (w >= 0) ? w : -w;
		//кут для розрахунку координат трьох інших точок за сторонами та координатами точки а
		double insin = (_angle == 90) ? 1 : sin(_angle * _myPi / 180);
		double incos = (_angle == 90) ? 0 : cos(_angle * _myPi / 180);

		_b = Point(_a.x() + _h * incos, _a.y() + _h * insin);
		_c = Point(_a.x() + _w + _h * incos, _a.y() + _h * insin);
		_d = Point(_a.x() + _w, _a.y());

		return;
	};
	HTetragon(const double ax = 0, const double ay = 0, const double h = 1, const double w = 2, const size_t angle = 90) : _a(ax, ay), _angle(angle), _ab(nullptr), _bc(nullptr), _cd(nullptr), _da(nullptr)
	{
		//на довжини накладається "модуль"
		_h = (h >= 0) ? h : -h;
		_w = (w >= 0) ? w : -w;
		//кут для розрахунку координат трьох інших точок за сторонами та координатами точки а
		double insin = (_angle == 90) ? 1 : sin(_angle * _myPi / 180);
		double incos = (_angle == 90) ? 0 : cos(_angle * _myPi / 180);

		_b = Point(_a.x(), _a.y() + _h * insin);
		_c = Point(_a.x() + _w + _w * incos, _a.y() + _h * insin);
		_d = Point(_a.x() + _w, _a.y());

		return;
	};
	HTetragon(const HTetragon& t) : HTetragon(t.apexA().x(), t.apexA().y(), t.h(), t.w(), t.angle()) {};
	
	~HTetragon()
	{
		if (_ab != nullptr) delete _ab;
		if (_bc != nullptr) delete _bc;
		if (_cd != nullptr) delete _cd;
		if (_da != nullptr) delete _da;
	};

	//геттери вершин чотирикутника
	const Point& apexA() const
	{
		return _a;
	};

	const Point& apexB() const
	{
		return _b;
	};

	const Point& apexC() const
	{
		return _c;
	};

	const Point& apexD() const
	{
		return _d;
	};

	const double angle() const
	{
		return _angle;
	};

	//сеттери вершин чотирикутника змінюють координати усього чотирикутника в залежності від зміненної вершини
	Point& setA(const double x, const double y)
	{
		if (_ab != nullptr) delete _ab;
		if (_bc != nullptr) delete _bc;
		if (_cd != nullptr) delete _cd;
		if (_da != nullptr) delete _da;

		_ab = nullptr;
		_bc = nullptr;
		_cd = nullptr;
		_da = nullptr;



		double tx = ((x >= 0) ? x : -x) - _a.x();
		double ty = ((y >= 0) ? y : -y) - _a.y();

		_a.x() = (x >= 0) ? x : -x;
		_a.y() = (y >= 0) ? y : -y;

		_b.x() += tx;
		_b.y() += ty;

		_c.x() += tx;
		_c.y() += ty;

		_d.x() += tx;
		_d.y() += ty;

		return _a;
	};

	Point& setB(const double x, const double y)
	{
		if (_ab != nullptr) delete _ab;
		if (_bc != nullptr) delete _bc;
		if (_cd != nullptr) delete _cd;
		if (_da != nullptr) delete _da;

		_ab = nullptr;
		_bc = nullptr;
		_cd = nullptr;
		_da = nullptr;

		double tx = ((x >= 0) ? x : -x) - _a.x();
		double ty = ((y >= 0) ? y : -y) - _a.y();

		_b.x() = (x >= 0) ? x : -x;
		_b.y() = (y >= 0) ? y : -y;

		_a.x() += tx;
		_a.y() += ty;

		_c.x() += tx;
		_c.y() += ty;

		_d.x() += tx;
		_d.y() += ty;

		return _b;
	};

	Point& setC(const double x, const double y)
	{
		if (_ab != nullptr) delete _ab;
		if (_bc != nullptr) delete _bc;
		if (_cd != nullptr) delete _cd;
		if (_da != nullptr) delete _da;

		_ab = nullptr;
		_bc = nullptr;
		_cd = nullptr;
		_da = nullptr;

		double tx = ((x >= 0) ? x : -x) - _a.x();
		double ty = ((y >= 0) ? y : -y) - _a.y();

		_c.x() = (x >= 0) ? x : -x;
		_c.y() = (y >= 0) ? y : -y;

		_b.x() += tx;
		_b.y() += ty;

		_a.x() += tx;
		_a.y() += ty;

		_d.x() += tx;
		_d.y() += ty;

		return _c;
	};

	Point& setD(const double x, const double y)
	{
		if (_ab != nullptr) delete _ab;
		if (_bc != nullptr) delete _bc;
		if (_cd != nullptr) delete _cd;
		if (_da != nullptr) delete _da;

		_ab = nullptr;
		_bc = nullptr;
		_cd = nullptr;
		_da = nullptr;

		double tx = ((x >= 0) ? x : -x) - _a.x();
		double ty = ((y >= 0) ? y : -y) - _a.y();

		_d.x() = (x >= 0) ? x : -x;
		_d.y() = (y >= 0) ? y : -y;

		_b.x() += tx;
		_b.y() += ty;

		_c.x() += tx;
		_c.y() += ty;

		_a.x() += tx;
		_a.y() += ty;

		return _d;
	};

	//геттери сторін чотирикутника, створюють їх при першому виклику чи після зміни координат точок
	const Segment& side_a()
	{
		if (_ab == nullptr) _ab = new Segment(_a, _b);
		return *_ab;
	};

	const Segment& side_b()
	{
		if (_bc == nullptr) _bc = new Segment(_b, _c);
		return *_bc;
	};

	const Segment& side_c()
	{
		if (_cd == nullptr) _cd = new Segment(_c, _d);
		return *_cd;
	};

	const Segment& side_d()
	{
		if (_da == nullptr) _da = new Segment(_d, _a);
		return *_da;
	};

	//геттери довжин сторін чотирикутника
	const double h() const
	{
		return _h;
	};

	const double w() const
	{
		return _w;
	};

	//геттер площі чотирикутника
	const double area() const
	{
		double insin = (_angle == 90) ? 1 : sin(_angle * _myPi / 180);
		return _h * _w * insin;
	};

	//оператор вкладання перевіряє можливість вкласти один чотирикутник в інший за площами та сторонами
	bool operator<(const HTetragon& r) const
	{
		return (this->area() < r.area()) && (this->_h < r._h) && (this->_w < r._w);
	};


};

//оператор об'єднання чотирикутників, повертає такий, що містить обидва і є найменшим, через порівняння крайніх точок
HTetragon operator+(const HTetragon& r, const HTetragon& r1)
{
	double x1, y1, x2, y2;
	if (r.apexA().x() < r1.apexA().x())
	{
		x1 = r.apexA().x();
	}
	else
	{
		x1 = r1.apexA().x();
	}

	if (r.apexC().x() > r1.apexC().x())
	{
		x2 = r.apexC().x();
	}
	else
	{
		x2 = r1.apexC().x();
	}

	if (r.apexA().y() < r1.apexA().y())
	{
		y1 = r.apexA().y();
	}
	else
	{
		y1 = r1.apexA().y();
	}

	if (r.apexC().y() < r1.apexC().y())
	{
		y2 = r1.apexC().y();
	}
	else
	{
		y2 = r.apexC().y();
	}


	double h = y2 - y1;
	double w = x2 - x1;

	HTetragon temp(x1, y1, h, w);

	return temp;
}

//оператор виводу вершин, сторін та площі
ostream& operator<<(ostream& os, HTetragon& s)
{
	os << "apex a: " << s.apexA() << "apex b: " << s.apexB() << "apex c: " << s.apexC() << "apex d: " << s.apexD() << "side a: " << s.side_a() << "side b: " << s.side_b() <<
		"side c: " << s.side_c() << "side d: " << s.side_d() << "area: " << s.area();
	return os;
}