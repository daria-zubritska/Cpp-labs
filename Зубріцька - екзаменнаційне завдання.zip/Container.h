﻿#pragma once;
#include <iostream>;
#include "Array.h";

using namespace std;

template <class Elem>
class Array;

template <class Elem>
class Container : public Array<Elem> {

public:

	class BadCon
	{

	private:

		string _reason;

	public:

		BadCon(const string& reason = "unknown") : _reason(reason)
		{
			return;
		}

		~BadCon() {}

		void diagnose() const
		{
			cerr << _reason;
			cerr << endl;
			return;
		}
	};

	Container(const size_t capacity = _default);
	~Container();

	size_t capacity() const;
	size_t size() const;

	bool empty() const;
	bool full() const;

	Container& clear();

	const Elem& operator[](const size_t) const;
	Elem& operator[](const  size_t);

	Container& add(const Elem&);
	Container& insert(const Elem&, const  size_t);

	Container& cut();
	Container& remove(const size_t);

	void allSmallerThan(const Elem&, Container<Elem>&);

	bool contains(const Elem&);

private:

	size_t _size;
	static const size_t _default = 0;
	Array<Elem>* _allocator;

	void reduce(const size_t times = 2);
	void enlarge(const size_t times = 2);

	Container& doinsert(const Elem&, const size_t);
	Container& doremove(const size_t);

	//заборонені у масивах операції
	Container(const Container&);
	Container& operator=(const Container&);
};


template<class Elem>
Container<Elem>::Container(const size_t capacity) : _size(0), _allocator(new Array<Elem>(capacity))
{
	return;
}

template<class Elem>
Container<Elem>::~Container()
{
	delete _allocator;
}

template<class Elem>
size_t Container<Elem>::capacity() const
{
	return _allocator->size();
}

template<class Elem>
size_t Container<Elem>::size() const
{
	return _size;
}

template<class Elem>
bool Container<Elem>::empty() const
{
	return _size == 0;
}

template<class Elem>
bool Container<Elem>::full() const
{
	return _size == capacity();
}

template<class Elem>
Container<Elem>& Container<Elem>::clear()
{
	_size = 0;
	return *this;
}

template<class Elem>
const Elem& Container<Elem>::operator[](const size_t index) const
{
	if (empty()) throw BadCon("Try to manipulate the empty sequence");
	if (index >= _size) throw BadCon("Try to access a non existing element of the sequence");
	return _allocator->operator[](index);
}

template<class Elem>
Elem& Container<Elem>::operator[](const size_t index)
{
	if (empty()) throw BadCon("Try to manipulate the empty sequence");
	if (index >= _size) throw BadCon("Try to access a non existing element of the sequence");

	return _allocator->operator[](index);
}

template<class Elem>
Container<Elem>& Container<Elem>::add(const Elem& elem)
{
	return doinsert(elem, _size);
}

template<class Elem>
Container<Elem>& Container<Elem>::insert(const Elem& elem, const size_t index)
{
	if (_size < index) throw BadCon("Try to insert after a non existing element of the sequence");

	return doinsert(elem, index);
}

template<class Elem>
Container<Elem>& Container<Elem>::cut()
{
	if (empty()) throw BadCon("Try to manipulate the empty sequence");
	return doremove(_size);
}

template<class Elem>
Container<Elem>& Container<Elem>::remove(const size_t index)
{
	if (empty()) throw BadCon("Try to manipulate the empty sequence");
	if (index >= _size) throw BadCon("Try to access a non existing element of the sequence");

	return doremove(index);
}

template<class Elem>
void Container<Elem>::allSmallerThan(const Elem& elem, Container<Elem>& temp)
{
	if (empty()) throw BadCon("Try to manipulate the empty sequence");

	for(size_t i = 0; i < size(); ++i)
	{
		if ((*_allocator)[i] < elem) temp.add(Elem((*_allocator)[i]));
	}
}

template<class Elem>
bool Container<Elem>::contains(const Elem& elem)
{
	if (empty()) return false;

	for (size_t i = 0; i < size(); ++i) {
		if ((*this)[i] == elem) return true;
	}

	return false;
}

template<class Elem>
void Container<Elem>::reduce(const size_t times)
{
	Array* newArr = new Array(_default / times + capacity() + 1);

	for (size_t i = 0; i < _size; i++)
	{
		(*newArr)[i] = (*_allocator)[i];
	}

	delete _allocator;

	_allocator = newArr;
}

template<class Elem>
void Container<Elem>::enlarge(const size_t times)
{
	Array<Elem>* newArr = new Array<Elem>(times * _default + capacity() + 1);

	for (size_t i = 0; i < _size; i++)
	{
		(*newArr)[i] = (*_allocator)[i];
	}

	delete _allocator;

	_allocator = newArr;
}

template<class Elem>
Container<Elem>& Container<Elem>::doinsert(const Elem& elem, const size_t index)
{
	if (_size + 1 > capacity()) enlarge();
	++_size;

	for (size_t i = _size - 1; i > index; i--)
	{
		(*_allocator)[i] = (*_allocator)[i - 1];
	}

	(*_allocator)[index] = elem;
	return *this;
}

template<class Elem>
Container<Elem>& Container<Elem>::doremove(const size_t index)
{
	--_size;

	for (size_t i = index; (i < _size) && (i >= 0); ++i)
	{
		(*_allocator)[i] = (*_allocator)[i + 1];
	}

	return *this;
}
