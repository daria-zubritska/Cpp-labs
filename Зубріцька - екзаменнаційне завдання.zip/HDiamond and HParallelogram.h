﻿#pragma once
#include <iostream>;
#include "Point.h";
#include "Segment.h";
#include "HTetragon.h";

using namespace std;


//уся реалізація знаходиться у HTetragon

class HDiamond : public HTetragon
{
public: 
	HDiamond(const Point& a, const double h, const size_t angle) : HTetragon(a, h, h, angle)
	{};
	HDiamond(const double ax = 0, const double ay = 0, const double h = 2, const size_t angle = 45) : HTetragon(ax, ay, h, h, angle)
	{};
	~HDiamond()
	{};
};

class HParallelogram : public HTetragon
{
public:
	HParallelogram(const Point& a, const double h, const double w, const double angle) : HTetragon(a, h, w, angle)
	{};
	HParallelogram(const double ax = 0, const double ay = 0, const double h = 2, const double w = 3, const double angle = 45) : HTetragon(ax, ay, h, w, angle)
	{};
	~HParallelogram()
	{};
};