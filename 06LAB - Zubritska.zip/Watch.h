#pragma once

#include <iostream>;
#include "Time.h";
using namespace std;

class Watch {

private:
	Time _beginning;
	Time _end;
	unsigned int _sleepTime = 1000;

public:

	Watch(Time&, Time&);
	Watch(Time&);
	~Watch() {};

	const Time& beginning() const;
	const Time& end() const;

	Time& beginning();
	Time& end();

	void startWatch();

};
