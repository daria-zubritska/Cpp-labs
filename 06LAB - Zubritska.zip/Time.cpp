﻿#include <iostream>;
#include "Time.h";

using namespace std;

Time::Time (const unsigned int s, const unsigned int m, const unsigned int h) : _seconds(s), _minutes(m), _hours(h) 
{
	normalizeTime();
}

Time::Time(const Time& t) : _seconds(t._seconds), _minutes(t._minutes), _hours(t._hours) 
{
}

Time& Time::operator=(const Time& t) 
{
	_hours = t._hours; _minutes = t._minutes; _seconds = t._seconds;
	return *this;
}

void Time::normalizeTime() 
{
	_hours += ((_minutes + (_seconds / 60)) / 60);
	_minutes = (_minutes + (_seconds / 60)) % 60; 
	_seconds %= 60;

	_hours %= 24;
}


void Time::setHours(const unsigned int h) 
{
	_hours = h; 
	normalizeTime();
	return;
}

void Time::setMinutes(const unsigned int m) 
{
	_minutes = m; 
	normalizeTime();
	return;
}

void Time::setSeconds(const unsigned int s) 
{
	_seconds = s; 
	normalizeTime();
	return;
}

void Time::decrease(Time& t)
{
	if (t.seconds() == 0)
	{
		t.setSeconds(59);

		if (t.minutes() == 0)
		{
			t.setMinutes(59);

			if (t.hours() == 0)
			{
				t.setHours(23);
			}
			else
			{
				t.setHours(t.hours() - 1);
			}
		}
		else
		{
			t.setMinutes(t.minutes() - 1);
		}
	}
	else
	{
		t.setSeconds(t.seconds() - 1);
	}
}

bool Time::operator==(const Time& t) const
{
	return (this->hours() == t.hours())&&(this->minutes() == t.minutes())&&(this->seconds() == t.seconds());
}

bool Time::operator!=(const Time& t) const
{
	return !(*this == t);
}

bool Time::operator<=(const Time& t) const
{
	return (*this == t) || (*this < t);
}

bool Time::operator<(const Time& t) const
{
	if (this->hours() == t.hours())
	{
		if (this->minutes() == t.minutes())
		{
			if (this->seconds() < t.seconds()) return true;
		}
		else if (this->minutes() < t.minutes()) return true;
	}
	else if (this->hours() < t.hours()) return true;

	return false;
}

bool Time::operator>=(const Time& t) const
{
	return (*this == t) || (*this > t);
}

bool Time::operator>(const Time& t) const
{
	if (this->hours() == t.hours())
	{
		if (this->minutes() == t.minutes())
		{
			if (this->seconds() > t.seconds()) return true;
		}
		else if (this->minutes() > t.minutes()) return true;
	}
	else if (this->hours() > t.hours()) return true;

	return false;
}

const Time& operator++(Time& t) 
{
	t.setSeconds(t.seconds() + 1);
	return t;
}

const Time operator++(Time& t, int) 
{
	const Time res(t); 
	t.setSeconds(t.seconds() + 1); 
	return res; 
}

const Time& operator--(Time& t)
{
	t.decrease(t);
	return t;
}

const Time operator--(Time& t, int)
{
	const Time res(t);
	t.decrease(t);
	return res;
}

ostream& operator<<(ostream& os, const Time& t) 
{
	os << "(" << t.hours() << ":" << t.minutes() << ":" << t.seconds() << ")";
	return os;
}

