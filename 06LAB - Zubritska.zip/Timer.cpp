#include <iostream>;
#include "Time.h";
#include "Timer.h";
#include "windows.h"

using namespace std;

Timer::Timer(Time& time): _countdownTime(time)
{
}

const Time& Timer::countdown() const
{
	return _countdownTime;
}

Time& Timer::countdown()
{
	return _countdownTime;
}

void Timer::startTimer()
{
	Time zero = Time();
	cout << countdown() << endl;

	while (countdown() != zero) 
	{
		Sleep(_sleepTime);
		--countdown();
		cout << countdown() << endl;
	}

	cout << "Time`s up" << endl;
}
