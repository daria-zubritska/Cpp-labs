#include <iostream>;
#include "Time.h";
#include "Watch.h"
#include "windows.h"

using namespace std; 

Watch::Watch(Time& beginning, Time& end) : _beginning(beginning), _end(end)
{

}

Watch::Watch(Time& end) : _beginning(Time()), _end(end)
{
}

const Time& Watch::beginning() const
{
	return _beginning;
}

const Time& Watch::end() const
{
	return _end;
}

Time& Watch::beginning()
{
	return _beginning;
}

Time& Watch::end()
{
	return _end;
}

void Watch::startWatch()
{
	if (beginning() <= end()) {
		cout << beginning() << endl;


		while (beginning() != end())
		{
			Sleep(_sleepTime);
			++beginning();
			cout << beginning() << endl;
		}
	}
	else
	{
		cout << end() << endl;


		while (beginning() != end())
		{
			Sleep(_sleepTime);
			++end();
			cout << end() << endl;
		}
	}
	cout << "Alarm!!!" << endl;
	
}
