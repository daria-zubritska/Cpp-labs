#include <iostream>;
#include "Time.h";
#include "Timer.h";
#include "Watch.h";

using namespace std;

int main() 
{
	Time zero = Time();
	Time a = Time(60, 60, 24);
	Time b = Time(60, 60, 23);

	Time c = Time(35, 27, 12);
	Time e = Time(1, 1, 0);

	cout << zero << endl;
	cout << "a:" << a << endl;
	cout << "b:" << b << endl;
	cout << "c:" << c << endl;
	cout << "e:" << e << endl;

	if (b <= e) cout << "b <= e" << endl;

	if (a > b) cout << "a > b" << endl;

	if (b >= e) 
	{
		cout << "b >= e" << endl;
	}
	else 
	{
		cout << "b <= e" << endl;
	}

	if (a < b)
	{
		cout << "a < b" << endl;
	}
	else
	{
		cout << "a > b" << endl;
	}

	//zero sec zero min zero hour timer
	Timer timer1 = Timer(zero);
	timer1.startTimer();

	//timer for e period of time
	Timer timer2 = Timer(e);
	timer2.startTimer();


	Time q = Time(10, 1, 0);
	//alarm will work after counting from smallest to biggest of two time objects
	Watch w1 = Watch(b, q);
	w1.startWatch();

	Watch w2 = Watch(q, b);
	w2.startWatch();

	//one argument sets the beginning time = 0:0:0
	Time t = Time(10, 0, 0);
	Watch w3 = Watch(t);
	w3.startWatch();

	return 0;
}