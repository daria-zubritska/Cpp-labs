﻿#pragma once

#include <iostream>;
using namespace std;


class Time {
private:
	unsigned int _hours; 
	unsigned int _minutes; 
	unsigned int _seconds; 

	void normalizeTime();
public:
	Time(unsigned int s = 0, unsigned int m = 0, const unsigned int h = 0);
	Time(const Time&); 
	~Time() {}
	Time& operator=(const Time&);

	const unsigned int& hours() const { return _hours; }
	const unsigned int& minutes() const { return _minutes; }
	const unsigned int& seconds() const { return _seconds; }

	void setHours(const unsigned int h);
	void setMinutes(const unsigned int m);
	void setSeconds(const unsigned int s);

	void decrease(Time&);

	bool operator==(const Time&) const;
	bool operator!=(const Time&) const;
	bool operator<=(const Time&) const;
	bool operator<(const Time&) const;
	bool operator>=(const Time&) const;
	bool operator>(const Time&) const;
};

const Time& operator++(Time&);
const Time operator++(Time&, int);
const Time& operator--(Time&);
const Time operator--(Time&, int);
ostream& operator<<(ostream&, const Time&);