#pragma once

#include <iostream>;
#include "Time.h";
using namespace std;

class Timer {

private:
	Time _countdownTime;
	unsigned int _sleepTime = 1000;

public:

	Timer(Time&);
	~Timer() {};

	const Time& countdown() const;
	Time& countdown();

	void startTimer();
	
};
