#include "Point.h"
#include "Segment.h"
#include "04LAB.h"

#include <iostream>
using namespace std;

int main()
{
	Point u, v(0, 3), w(4);

	Triangle ABC(u, v, w);
	cout << "ABC " << ABC;

	Triangle a, b(2, 0, 2, 2, 0, 2), c(b);
	
	cout << a << endl;
	cout << b << endl;
	cout << c << endl;

	b = ABC;
	cout << "new value of b " << b << endl;

	cout << "medians of b: " << endl;
	cout << "median of side a: " << b.median_a() << endl;
	cout << "median of side b: " << b.median_b() << endl;
	cout << "median of side c: " << b.median_c() << endl;

	cout << "side b of b: " << b.side_b() << endl;
	cout << "point a of b: " << b.apexA() << endl;
	b.apexA() = Point(5,5);
	cout << "side b of b: " << b.side_b() << endl;
	cout << "point a of b: " << b.apexA() << endl;
	cout << "median of side c: " << b.median_c() << endl;

	cout << "Triangles " << Triangle::epilog() << endl;
	cout << "Segments  " << Segment::amount() << endl;
	cout << "Points    " << Point::amount() << endl;

	return 0;
}
