﻿#pragma once

#include "Point.h"
#include <iostream>;

using namespace std;


// 02LAB. Реалізувати і протестувати тип даних Segment



//*******************************************

//Every segment posesses its unique ID.

//In debug mode both constructor and destructor

//report the ID and the coordinates

//of a segment created or resp. deleted

//Developed by Zubritska Daria

//at ....................

//Version 1.0

//*******************************************



// Клас відрізків


class Segment

{

private:

	// Засоби облікування відрізків

	static int _freeID;

	const int _myID;

	// Точка початку відрізку

	Point &_a;

	// Точка кінця відрізку

	Point &_b;

public:


	Segment(Point& start, Point& end);

	~Segment();

	// Присвоєння

	Segment& operator=(const Segment&);

	// Селектори  точок

	const Point& start() const;

	const Point& end() const;

	// Селектори-модифікатори точок

	Point& start();

	Point& end();

	// Селектори координат точок

	const double& startX() const;

	const double& startY() const;

	const double& endX() const;

	const double& endY() const;

	// Селектори-модифікатори координат точок

	double& startX();

	double& startY();

	double& endX();

	double& endY();

	// Обчислення довжини відрізка

	double length() const;

	// Обчислення відстані від відрізка до точки

	double distance(const Point&) const;

	// Селектор ID

	const int getID() const;

	static int amount();

};

bool operator==(const Segment& u, const Segment& v);

bool operator!=(const Segment& u, const Segment& v);

ostream& operator<<(ostream&, const Segment&);

