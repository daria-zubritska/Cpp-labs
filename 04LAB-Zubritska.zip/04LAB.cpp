﻿#include "Point.h"
#include "Segment.h"
#include "04LAB.h"
#include <cassert>
#include <cmath>

int Triangle::_call = 0;
ofstream Triangle::out("Triangle.txt");

Triangle::Triangle(const double x1, const double y1,
	const double x2, const double y2,
	const double x3, const double y3) :
	_a(x1, y1), _b(x2, y2), _c(x3, y3), _ab(nullptr), _bc(nullptr), _ca(nullptr), _medA(nullptr), _medB(nullptr), _medC(nullptr)
{
	++_call;
	assert(area() != 0);
	return;
}

Triangle::Triangle(const Point& a, const Point& b, const Point& c) :
	_a(a), _b(b), _c(c), _ab(nullptr), _bc(nullptr), _ca(nullptr), _medA(nullptr), _medB(nullptr), _medC(nullptr)
{
	++_call;
	assert(area() != 0);
	return;
}

Triangle::Triangle(const Triangle& t) :
	_a(t._a), _b(t._b), _c(t._c), _ab(nullptr), _bc(nullptr), _ca(nullptr), _medA(nullptr), _medB(nullptr), _medC(nullptr)
{
	++_call;
	return;
};
Triangle::~Triangle()
{
	if (_ab != nullptr) delete _ab;	
	if (_bc != nullptr) delete _bc;
	if (_ca != nullptr) delete _ca;
	if (_medA != nullptr) delete _medA;
	if (_medB != nullptr) delete _medB;
	if (_medC != nullptr) delete _medC;
};
Triangle& Triangle::operator= (const Triangle& t)
{
	++_call;
	_a = t._a;
	_b = t._b;
	_c = t._c;
	if (_ab != nullptr) delete _ab;
	if (_bc != nullptr) delete _bc;
	if (_ca != nullptr) delete _ca;
	if (_medA != nullptr) delete _medA;
	if (_medB != nullptr) delete _medB;
	if (_medC != nullptr) delete _medC;
	_ab = nullptr;
	_bc = nullptr;
	_ca = nullptr;
	_medA = nullptr;
	_medB = nullptr;
	_medC = nullptr;
	return *this;
}

double Triangle::perimeter()
{
	return side_a().length() + side_b().length() + side_c().length();
}


double Triangle::area()
{
	return 0.5 * side_a().length() * side_a().distance(_a);
}

const Segment& Triangle::median_a()
{
	if (_medA == nullptr)
	{
		_midA = Point((side_a().startX() + side_a().endX()) / 2, (side_a().startY() + side_a().endY()) / 2);
		_medA = new Segment(_a, _midA);
	}
	return *_medA;
}

const Segment& Triangle::median_b()
{
	if (_medB == nullptr) 
	{
		_midB = Point((side_b().startX() + side_b().endX()) / 2, (side_b().startY() + side_b().endY()) / 2);
		_medB = new Segment(_b, _midB);
	}
	return *_medB;
}

const Segment& Triangle::median_c()
{
	if (_medC == nullptr) 
	{
		_midC = Point((side_c().startX() + side_c().endX()) / 2, (side_c().startY() + side_c().endY()) / 2);
		_medC = new Segment(_c, _midC);
	}
	return *_medC;
}

const Point& Triangle::apexA() const
{
	return _a;
}
const Point& Triangle::apexB() const
{
	return _b;
}
const Point& Triangle::apexC() const
{
	return _c;
}

Point& Triangle::apexA()
{
	if (_ab != nullptr) delete _ab;
	if (_bc != nullptr) delete _bc;
	if (_ca != nullptr) delete _ca;
	if (_medA != nullptr) delete _medA;
	if (_medB != nullptr) delete _medB;
	if (_medC != nullptr) delete _medC;
	_ab = nullptr;
	_bc = nullptr;
	_ca = nullptr;
	_medA = nullptr;
	_medB = nullptr;
	_medC = nullptr;
	return _a;
}
Point& Triangle::apexB()
{
	if (_ab != nullptr) delete _ab;
	if (_bc != nullptr) delete _bc;
	if (_ca != nullptr) delete _ca;
	if (_medA != nullptr) delete _medA;
	if (_medB != nullptr) delete _medB;
	if (_medC != nullptr) delete _medC;
	_ab = nullptr;
	_bc = nullptr;
	_ca = nullptr;
	_medA = nullptr;
	_medB = nullptr;
	_medC = nullptr;
	return _b;
}
Point& Triangle::apexC()
{
	if (_ab != nullptr) delete _ab;
	if (_bc != nullptr) delete _bc;
	if (_ca != nullptr) delete _ca;
	if (_medA != nullptr) delete _medA;
	if (_medB != nullptr) delete _medB;
	if (_medC != nullptr) delete _medC;
	_ab = nullptr;
	_bc = nullptr;
	_ca = nullptr;
	_medA = nullptr;
	_medB = nullptr;
	_medC = nullptr;
	return _c;
}

const Segment& Triangle::side_a() 
{
	if (_bc == nullptr) _bc = new Segment(_b, _c);
	return *_bc;
}
const Segment& Triangle::side_b() 
{
	if (_ca == nullptr) _ca = new Segment(_c, _a);
	return *_ca;
}
const Segment& Triangle::side_c() 
{
	if (_ab == nullptr) _ab = new Segment(_a, _b);
	return *_ab;
}

ostream& Triangle::show(ostream& os)
{
	os << "Triangle: " << apexA() << apexB() << apexC() << endl;
	os << side_a();
	os << side_b();
	os << side_c();
	os << "perimeter " << perimeter() << endl;
	os << "area      " << area() << endl << endl;
	return os;
}
int Triangle::epilog()
{
	out << "N calls " << _call << endl;
	return _call;
}

ostream &operator<<(ostream& os, Triangle& t)
{
	return t.show(os);
}