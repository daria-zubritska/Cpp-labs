#ifndef _TRIANGLE_H_
#define _TRIANGLE_H_

#include <iostream>
#include <fstream>
#include "Point.h"
#include "Segment.h"
using namespace std;

// Version 0.1
// To be developed to a version 1.0
// of the well balanced triangle
// with atributes Segment*
// for sides and medians
class Triangle
{
private:
	static ofstream out;
	static int _call;
	Point _a, _b, _c, _midA, _midB, _midC;
	Segment *_ab, *_bc, *_ca, *_medA, *_medB, *_medC;

public:
	Triangle(const double x1 = 0, const double y1 = 0,
		const double x2 = 1, const double y2 = 0,
		const double x3 = 0, const double y3 = 1);
	Triangle(const Point& a,
		const Point& b,
		const Point& c);
	Triangle(const Triangle&);
	~Triangle();
	Triangle& operator= (const Triangle&);
	double perimeter();
	double area();
	const Segment& median_a();
	const Segment& median_b();
	const Segment& median_c();

	const Point& apexA() const;
	const Point& apexB() const;
	const Point& apexC() const;

	Point& apexA();
	Point& apexB();
	Point& apexC();

	const Segment& side_a();
	const Segment& side_b();
	const Segment& side_c();

	static int epilog();

	ostream& show(ostream& os);
};

ostream& operator<<(ostream&, Triangle&);
#endif
