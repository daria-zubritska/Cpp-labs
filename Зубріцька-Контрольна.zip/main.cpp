#include <iostream>;
#include "Point.h";
#include "HRectangle.h";
#include "HSquare.h";

using namespace std;

int main()
{
	//1
	Point a(1, 1);
	HSquare s1(a, 5), s2(), s3(3, 2, -3);
	HRectangle r1(a, 5, -6), r2(), r3(1, 2, 2, 1);


	cout << "2 not full" << endl;
	cout << s1.apexA() << endl;
	cout << s1.apexB() << endl;
	cout << s1.apexC() << endl;
	cout << s1.apexD() << endl;
	return 0;
}