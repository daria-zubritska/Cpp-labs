#include "Point.h"
#include "Segment.h";
#include <iostream>;
#include <cmath>;

using namespace std;

int Segment::_freeID = 0;

Segment::Segment(const double x1, const double y1, const double x2, const double y2) : _a(x1, y1), _b(x2, y2), _myID(++_freeID)
{
	cout << "Creating: " << "Beggining " << '\n' << _a << "End \n" << _b << "ID of the segment: " << _myID << endl;
}

Segment::Segment(const Point& start, const Point& end) : _a(start), _b(end), _myID(++_freeID)
{
	cout << "Creating: " << "Beggining " << '\n' << _a << "End \n" << _b << "ID of the segment: " << _myID << endl;
}

Segment::Segment(const Segment& s) : _a(s.start()), _b(s.end()), _myID(++_freeID)
{
	cout << "Creating: " << "Beggining " << '\n' << _a << "End \n" << _b << "ID of the segment: " << _myID << endl;
}

Segment::~Segment()
{
	cout << "Deleting: " << "Beggining " << '\n' << _a << "End \n" << _b << "ID of the segment: " << _myID << endl;
}

Segment& Segment::operator=(const Segment& s)
{
	this->start() = s.start();
	this->end() = s.end();
	return *this;
}

const Point& Segment::start() const
{
	return _a;
}

const Point& Segment::end() const
{
	return _b;
}

Point& Segment::start()
{
	return _a;
}

Point& Segment::end()
{
	return _b;
}

const double& Segment::startX() const
{
	return _a.x();
}

const double& Segment::startY() const
{
	return _a.y();
}

const double& Segment::endX() const
{
	return _b.x();
}

const double& Segment::endY() const
{
	return _b.y();
}

double& Segment::startX()
{
	return _a.x();
}

double& Segment::startY()
{
	return _a.y();
}

double& Segment::endX()
{
	return _b.x();
}

double& Segment::endY()
{
	return _b.y();
}

double Segment::length() const
{
	return sqrt(pow((this->endX() - this->startX()), 2) + pow((this->endY() - this->startY()), 2));
}

double Segment::distance(const Point& p) const
{
	double m = (endY() - startY()) / (endX() - startX());

	if (p.y() - startY() == m * (p.x() - startX())) {
		return 0.0;
	}

	double dx = endX() - startX();
	double dy = endY() - startY();
	if ((dx == 0) && (dy == 0))
	{
		dx = p.x() - startX();
		dy = p.y() - startY();
		return sqrt(dx * dx + dy * dy);
	}

	double t = ((p.x() - startX()) * dx + (p.y() - startY()) * dy) / (dx * dx + dy * dy);

	if (t < 0)
	{
		dx = p.x() - startX();
		dy = p.y() - startY();
	}
	else if (t > 1)
	{
		dx = p.x() - endX();
		dy = p.y() - endY();
	}
	else
	{
		dx = p.x() - (startX() + t * dx);
		dy = p.y() - (startY() + t * dy);
	}

	return sqrt(dx * dx + dy * dy);
}

const int Segment::getID() const
{
	return _myID;
}

ostream& operator<<(ostream& os, const Segment& s)
{
	os << "Beggining " << '\n' << s.start() << "End \n" << s.end() << "ID of the segment: " << s.getID() << endl;
	return os;
}