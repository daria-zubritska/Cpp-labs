﻿#pragma once
#include <iostream>;
#include "Point.h";
#include "Segment.h";
#include "HTetragon.h";

using namespace std;

class HRectangle: public HTetragon
{
private:

	Point _a, _b, _c, _d;
	Segment *_ab, * _bc, * _cd, * _da;
	double _h;
	double _w;

	//Не орієнтовані довжини сторін
	double _lh;
	double _lw;

public:
	//1
	HRectangle(const Point& a, const double h, const double w) : _a(a), _h(h), _w(w) 
	{
		if (h < 0) _lh = -h;
		else _lh = h;

		if (w < 0) _lw = -w;
		else _lw = w;

		cout << "left bottom corner: " << _a << "; side a len: " << _lh << "; side b len: " << _lw << endl;

		return;
	};
	HRectangle(const double ax = 0, const double ay = 0, const double h = 1, const double w = 2) : _a(ax, ay), _h(h), _w(w) 
	{
		if (h < 0) _lh = -h;
		else _lh = h;

		if (w < 0) _lw = -w;
		else _lw = w;

		cout << "left bottom corner: " << _a << "; side a len: " << _lh << "; side b len: " << _lw <<  endl;

		return;
	};
	~HRectangle() {};

	//2
	const Point& apexA() const;
	const Point& apexB() const;
	const Point& apexC() const;
	const Point& apexD() const;

	const Point& setA() const;
	const Point& setB() const;
	const Point& setC() const;
	const Point& setD() const;

};