﻿#pragma once
#include <iostream>;
#include "Point.h";
#include "Segment.h";
#include "HTetragon.h";

using namespace std;

class HSquare: public HTetragon
{
private:

	Point _a, _b, _c, _d;
	Segment *_ab, * _bc, * _cd, * _da;
	double _h;

	//Не орієнтована довжина сторони
	double _lh;

public:

	//1
	HSquare(const Point& a, const double h) : _a(a), _h(h)
	{
		if (h < 0) _lh = -h;
		else _lh = h;
		_b = Point(_a.x(), _a.y() + _lh);
		_c = Point(_a.x() + _lh, _a.y() + _lh);
		_d = Point(_a.x() + _lh, _a.y());
		cout << "left bottom corner: " << _a << "; side len: " << _lh << endl;

		return;
	};
	HSquare(const double ax = 0, const double ay = 0, const double h = 1) : _a(ax, ay), _h(h) 
	{
		if (h < 0) _lh = -h;
		else _lh = h;

		cout << "left bottom corner: " << _a << "; side len: " << _lh << endl;

		return;
	};
	~HSquare() {};


	//2
	const Point& apexA() const;
	const Point& apexB() const;
	const Point& apexC() const;
	const Point& apexD() const;

	const Point& setA() const;
	const Point& setB() const;
	const Point& setC() const;
	const Point& setD() const;
};