#include <iostream>;
#include "Point.h";
#include "Segment.h";
#include "HTetragon.h";
#include "HSquare.h"

const Point& HSquare::apexA() const
{
	return _a;
}

const Point& HSquare::apexB() const
{
	return _b;
}

const Point& HSquare::apexC() const
{
	return _c;
}

const Point& HSquare::apexD() const
{
	return _d;
}

const Point& HSquare::setA() const
{

	return _a;
}

const Point& HSquare::setB() const
{
	return _b;
}

const Point& HSquare::setC() const
{
	return _c;
}

const Point& HSquare::setD() const
{
	return _d;
}
