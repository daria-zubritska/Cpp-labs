#pragma once
#include <iostream>;
#include "Point.h";
#include "Segment.h";

using namespace std;

//2
class HTetragon
{
private:

	Point _a, _b, _c, _d;
	Segment* _ab, * _bc, * _cd, * _da;

public:

	const Point& apexA() const;
	const Point& apexB() const;
	const Point& apexC() const;
	const Point& apexD() const;

	const Point& setA() const;
	const Point& setB() const;
	const Point& setC() const;
	const Point& setD() const;

};