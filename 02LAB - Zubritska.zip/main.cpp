#include "Point.h"
#include "02LAB.h";
#include <iostream>;

using namespace std;

int main() 
{
	Segment s1 = Segment();
	Segment s2 = Segment(1.0, 1.0, 2.0, 2.0);
	Segment s3 = Segment(s1);

	Point p1 = Point();
	Point p2 = Point(4, 4);

	Segment s4 = Segment(p1, p2);

	s4 = s3;
	cout << "s4 = s3 " << s4 << endl;

	cout << "Before setters: s2 start: " << s2.start() << endl;
	cout << "s2 end: " << s2.end() << endl;
	cout << "s2 startX: " << s2.startX() << endl;
	cout << "s2 startY: " << s2.startY() << endl;
	cout << "s2 endX: " << s2.endX() << endl;
	cout << "s2 endY: " << s2.endY() << endl;

	s2.start() = Point(11, 11);
	s2.end() = Point(21, 21);

	cout << "After setters: s2 start: " << s2.start() << endl;
	cout << "s2 end: " << s2.end() << endl;

	s2.startX() = 10;
	s2.startY() = 1;
	s2.endX() = 20;
	s2.endY() = 2;

	cout << "After more setters: s2 startX: " << s2.startX() << endl;
	cout << "s2 startY: " << s2.startY() << endl;
	cout << "s2 endX: " << s2.endX() << endl;
	cout << "s2 endY: " << s2.endY() << endl;

	cout << "s1 length: " << s1.length() << endl;

	cout << "distance from s1 to p2: " << s1.distance(p2) << endl;

	cout << "s4 ID: " << s4.getID() << endl;

	cout << "s3: " << s3 << endl;

	return 0;
}