#include "01LAB.h";
#include <iostream>;

using namespace std;

int main() 
{

	Point p1 = Point();

	Point p2(2, 2);

	Point p3(p1);

	cout << "Amount: " << Point::amount() << endl;

	cout << "ID of the second point: " << p2.getID() << endl;

	cout << "x of the second point before setter: " << p2.x() << endl;

	p2.x() = 4;

	cout << "x of the second point after setter: " << p2.x() << endl;

	cout << "y of the third point before setter: " << p3.y() << endl;

	p3.y() = 7;

	cout << "y of the third point after setter: " << p3.y() << endl;

	Point p4 = p2 + p3;

	cout << "p4 = p2 + p3" << '\n' << p4 << endl;

	p4 += p3;

	cout << "p4 += p3 " << '\n' << p4 << endl;

	if (p4 != p3) {
		cout << p4 << "Is not equal to" << '\n' << p3 << endl;
	}

	p4 = p3;

	cout << " p4 = p3 " << '\n' << p4 << endl;

	if (p4 == p3) {
		cout << p4 << "Is equal to" << '\n' << p3 << endl;
	}

	return 0;
}