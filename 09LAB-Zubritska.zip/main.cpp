﻿#include <string>; 
#include <iostream>;
#include "09LAB.h";

using namespace std;

int main() {
	Array<int> arra(3);
	cout << arra << endl; 
	arra[0] = 1;
	arra[1] = 3;
	arra[2] = 22;
	cout << arra << endl;

	Array<char> arrc(4); 
	cout << arrc << endl;
	arrc[0] = 'a';
	arrc[1] = 'j';
	arrc[2] = 'c';
	arrc[3] = 'w';
	cout << arrc << endl;

	Array<string> arrs(2);
	cout << arrs << endl;
	arrs[0] = "first";
	arrs[1] = "second";
	cout << arrs << endl;

	try {
		arrc[10];
	}
	catch (const Array<char>::BadArray& x) {
		cerr << "Non-existing symbol" << endl; 
		x.diagnose();
	}

	try {
		arra[-1];
	}
	catch (const Array<int>::BadArray& x) {
		cerr << "Non-existing number" << endl;
		x.diagnose();
	}

	try {
		arrs[-10];
	}
	catch (const Array<string>::BadArray& x) {
		cerr << "Non-existing string" << endl;
		x.diagnose();
	}
	
	return 0;
}