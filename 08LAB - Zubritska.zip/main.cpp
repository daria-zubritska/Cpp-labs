﻿#include "08LAB.h"
#include <iostream>

using namespace std;

int main() {
	const ConstAction menuConst[] = {&Screen::home, &Screen::move, &Screen::back, &Screen::show};

	Screen v(5, 5, "/////...../////...../////");

	size_t k, n; 
	char ch; 

	v.show();

	do {
			cout << "(0-home; 1-move; 2-back; 3-show; 4-move(i, j); 5-set 6-exit;)"; 
			cin >> k;

			if (k == 6) break;

			if (k == 4)
			{
				unsigned int i;
				cout << "i = ";
				cin >> i;

				unsigned int j;
				cout << "j = ";
				cin >> j;

				v.move(i, j);
			}
			else if (k == 5)
			{
				char ch;
				cin >> ch;
				v.set(ch);
			}
			else
			{
				cout << "multiplicity? ";
				cin >> n;

				doActionConst(v, menuConst[k], n);
			}
	} while (true);

	v.show();


	return 0;
}