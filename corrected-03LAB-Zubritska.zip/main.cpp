#include "03LAB.h";
#include <iostream>

int main()
{
    //one of the created dates is a default date that hasn`t been set yet
    Date d1(5, 3, 342);
    Date d2(d1);

    //d1.setDefault(6, Date::Month(3), 2000);
    d1.setDefault();

    d1.setDay(10);
    d1.setMonth(10);
    d1.setYear(2021);

    cout << "Date after editing: " << d1 << endl;

    cout << "Case of inserting the incorrect date: " << endl;
    d1.setMonth(2);
    d1.setDay(31);
    cout << "Date is automatically set to the closest correct of the incorrect one" << endl;

    cout << "Default date cannot be set second time: " << endl;
    d1.setDefault(1, Date::Month(1), 1);
    d1.showDefault();

    cout << "Date with getters: " << d1.day() << '.' << d1.getMonthName() << '(' << d1.month() << ")." << d1.year() << endl;

    cout << "++ and -- test" << endl;
    cout << "casual date" << endl;
    Date d6(24, 3, 2016);
    cout << d6 << endl;
    d6++;
    cout << d6 << endl;

    d6--;
    cout << d6 << endl;

    cout << "end year date" << endl;
    Date d3(31, 12, 2000);
    cout << d3 << endl;
    d3++;
    cout << d3 << endl;

    d3--;
    cout << d3 << endl;

    cout << "leap year date" << endl;
    Date d4(29, 2, 2020);
    cout << d4 << endl;
    d4++;
    cout << d4 << endl;

    d4--;
    cout << d4 << endl;

    cout << "non leap year date" << endl;
    Date d5(28, 2, 2021);
    cout << d5 << endl;
    d5++;
    cout << d5 << endl;

    d5--;
    cout << d5 << endl;

    return 0;
}

