﻿#include "03LAB.h";
#include <iostream>;

using namespace std;

string Date::monthNames[12] = {"january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"};

bool Date::defaultSet = false;

Date Date::defaultDate = Date();

enum Month { jan = 1, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec };

Date::Date(int d, Month m, int y) 
{
	fillDate(d, m, y);
	cout << "Date set: " << _day << '.' << getMonthName() << '.' << _year << endl;
}

Date::Date(int d, int m, int y) : Date(d, Month(m), y)
{
}

Date::Date(const Date& d) : Date(d.day(), d.month(), d.year())
{
}

Date::~Date()
{
	cout << "Deleting: " << _day << '.' << getMonthName() << '.' << _year << endl;
}

int Date::day() const
{
	return _day;
}

Date::Month Date::month() const
{
	return Month(_month);
}

int Date::year() const
{
	return _year;
}

int Date::numDays(int m, int y) 
{
	switch (m) {
	case feb: return 28 + leapYear(y); 
	case apr: case jun: case sep: case nov: return 30;
	case jan: case mar: case may:
	case jul: case aug: case oct: case dec: return 31;
		// Місяць виявився некоректним 
	default: throw BadDate(_day, _month, _year);
	}
}

const string Date::getMonthName() const
{
	return monthNames[_month - 1];
}

void Date::setDay(int d)
{ 
	if ((d <= 0) || (d >= 32)) {
		cout << "Day is limited between 1 and 31" << endl;
		return;
	}

	fillDate(d, Month(_month), _year);

	cout << "Date edited: " << _day << '.' << getMonthName() << '.' << _year << endl;
}

void Date::setMonth(int m)
{
	if ((m <= 0) || (m >= 13)) {
		cout << "Month is limited between 1 and 12" << endl;
		return;
	}

	fillDate(_day, Month(m), _year);

	cout << "Date edited: " << _day << '.' << getMonthName() << '.' << _year << endl;
}

void Date::setYear(int y)
{
	if (y < 0) {
		cout << "year is supposed to be 0 or higher" << endl;
		return;
	}

	fillDate(_day, Month(_month), y);

	cout << "Date edited: " << _day << '.' << getMonthName() << '.' << _year << endl;
}

void Date::setDefault(int d, Month m, int y)
{
	if (defaultSet) return;

	defaultDate.setDay(d);
	defaultDate.setMonth(m);
	defaultDate.setYear(y);

	defaultSet = true;
	cout << "DefaultDate set as: " << defaultDate << endl;
}

void Date::setDefault()
{
	if (defaultSet) return;

	struct tm newtime;
	time_t now = time(0);
	localtime_s(&newtime, &now);

	defaultDate.setDay(newtime.tm_mday);
	defaultDate.setMonth(1 + newtime.tm_mon);
	defaultDate.setYear(1900 + newtime.tm_year);

	defaultSet = true;
	cout << "DefaultDate set as: " << defaultDate << endl;
}

void Date::showDefault()
{
	cout << "DefaultDate: " << defaultDate << endl;
}

const Date& Date::operator++()
{
	
	fillDate(++_day, Month(_month), _year);
	
	return *this;
}

const Date Date::operator++(int)
{
	Date d = *this;

	fillDate(++_day, Month(_month), _year);

	return d;
}

const Date& Date::operator--()
{

	fillDate(--_day, Month(_month), _year);

	return *this;

}

const Date Date::operator--(int)
{
	Date d = *this;
	
	fillDate(--_day, Month(_month), _year);

	return d;
}

bool Date::leapYear(int y)
{
	if (y % 4 == 0) {
		if (y % 100 == 0) {
			if (y % 400 == 0)
				return true;
			else
				return false;
		}
		else
			return true;
	}
	else
		return false;
}

void Date::fillDate(int d, Month m, int y) 
{
	_day = d;
	_month = m;
	_year = y;

	unsigned int numberOfDays = numDays(_month, _year);
	
	if (numberOfDays < d) 
	{
		_day = 1;
		_month = m + 1;
	}

	if (_month > 12 || m > 12) 
	{
		_month = 1;
		_year = y + 1;
	}


	if (0 >= d)
	{
		_month = m - 1;
		
		if (_month <= 0)
		{
			_month = 12;
			_year = y - 1;
		}

		_day = numDays(_month, _year);
	}

	if (_year < 0)
	{
		throw BadDate(_day, _month, _year);
	}
}

ostream& operator<<(ostream& os, const Date& d)
{
	return os << d.day() << '.' << d.getMonthName() << '.' << d.year() << endl;
}

ostream& operator<<(ostream& os, const Date::BadDate& bd)
{
	return os << "exception BadDate: " << bd._day << '.' << bd._month << '.' << bd._year << endl;
}

Date::BadDate::BadDate(int d, int m, int y) : _day(d), _month(m), _year(y)
{}
