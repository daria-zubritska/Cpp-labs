#include <iostream>;
#include "10LAB.h";

using namespace std;


int main() {

	Sequence<int> s;

	cout << "resizing and adding elements to the end of an empty sequence" << endl;
	
	cout << "capacity and size" << endl;
	cout << s.capacity() << endl;
	cout << s.size() << endl;

	cout << "insert 3" << endl;
	s.add(3);
	cout << "index = 0" << endl;
	cout << s[0] << endl;

	cout << "capacity and size" << endl;
	cout << s.capacity() << endl;
	cout << s.size() << endl;

	cout << "insert 5" << endl;
	s.add(5);
	cout << "index = 1" << endl;
	cout << s[1] << endl;

	cout << "capacity and size" << endl;
	cout << s.capacity() << endl;
	cout << s.size() << endl;

	cout << "insert 7" << endl;
	s.add(7);
	cout << "index = 1" << endl;
	cout << s[1] << endl;

	cout << "capacity and size" << endl;
	cout << s.capacity() << endl;
	cout << s.size() << endl;

	cout << "insert into the beginning" << endl;
	cout << "insert 10" << endl;
	s.insert(10, 0);
	cout << "index = 0" << endl;
	cout << s[0] << endl;

	cout << "capacity and size" << endl;
	cout << s.capacity() << endl;
	cout << s.size() << endl;

	cout << "clear" << endl;
	s.clear();
	try {
		cout << "index = 0" << endl;
		cout << s[0] << endl;
	}
	catch (Sequence<int>::BadSeq& r) {
		r.diagnose();
	}

	cout << "filling sequence up" << endl;
	s.add(0);
	s.add(1);
	s.add(2);
	s.add(3);
	s.add(4);

	cout << s[0] << s[1] << s[2] << s[3] << s[4] << endl;
	cout << "capacity and size" << endl;
	cout << s.capacity() << endl;
	cout << s.size() << endl;

	try {
		cout << "insert 7 at index 7" << endl;
		s.insert(7, 7);
	}
	catch (Sequence<int>::BadSeq& r) {
		r.diagnose();
	}
	cout << "cut" << endl;
	s.cut();
	cout << "capacity and size" << endl;
	cout << s.capacity() << endl;
	cout << s.size() << endl;
	try {
		cout << "s[0] << s[1] << s[2] << s[3] << s[4]" << endl;
		cout << s[0] << s[1] << s[2] << s[3] << s[4] << endl;
	}
	catch (Sequence<int>::BadSeq& r) {
		r.diagnose();
	}
	cout << s[0] << s[1] << s[2] << s[3] << endl;

	cout << "remove from index = 0" << endl;
	s.remove(0);
	cout << "capacity and size" << endl;
	cout << s.capacity() << endl;
	cout << s.size() << endl;
	try {
		cout << "s[0] << s[1] << s[2] << s[3]" << endl;
		cout << s[0] << s[1] << s[2] << s[3] << endl;
	}
	catch (Sequence<int>::BadSeq& r) {
		cout << "sequnce moved to the left" << endl;
		r.diagnose();
	}
	cout << s[0] << s[1] << s[2] << endl;

	cout << "contais(2)" << endl;
	if (s.contains(2)) cout << "yes" << endl;
	else cout << "no" << endl;
	cout << "contains(5)" << endl;
	if (s.contains(5)) cout << "yes" << endl;
	else cout << "no" << endl;

	return 0;
}