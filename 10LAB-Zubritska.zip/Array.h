﻿#pragma once
#include <iostream>;

using namespace std;

template <typename Elem>
class Array
{

public:

	class BadArray
	{

	private:

		string _reason;
		size_t _index;

	public:

		BadArray(const string& reason = "unknown", const size_t index = 0) : _reason(reason), _index(index)
		{
			return;
		}

		~BadArray() {}

		void diagnose() const
		{
			cerr << _reason; if (_index != 0) cerr << ' ' << _index;
			cerr << endl;
			return;
		}
	};


	Array(const size_t = 0);
	~Array();

	Elem& operator[](const size_t index);
	const Elem& operator[](const size_t index) const;
	size_t size() const;

private:
	const size_t _size;
	Elem* const _allocator;

	//Заборонені в масивах
	Array(const Array&);
	Array& operator=(const Array&);
};

template <typename Elem>
ostream& operator<<(ostream&, const Array<Elem>&);

template <typename Elem>
ostream& operator<<(ostream& os, const Array<Elem>& ar)
{
	char chr = ' ';
	cout << "Size: " << ar.size() << '[';

	for (size_t i = 0; i < ar.size(); i++)
	{
		cout << chr << ar[i];
		if (chr == ' ') chr = ',';
	}

	cout << ']' << endl;
	return os;
}

template <typename Elem>
Array<Elem>::Array(const size_t sz) : _size(sz), _allocator(new Elem[_size])
{
	return;
}

template <typename Elem>
Array<Elem>::~Array()
{
	delete[] _allocator;
}

template <typename Elem>
Elem& Array<Elem>::operator[](const size_t index)
{
	if (index >= _size || index < 0) throw BadArray("Incorrect index", index);
	return _allocator[index];
}

template <typename Elem>
const Elem& Array<Elem>::operator[](const size_t index) const
{
	if (index >= _size || index < 0) throw BadArray("Incorrect index", index);
	return _allocator[index];
}

template <typename Elem>
size_t Array<Elem>::size() const
{
	return _size;
}